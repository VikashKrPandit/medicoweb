<!DOCTYPE html>
<html>
<head>
  <title>Transaction Success</title>
  <!-- Latest CSS -->
 <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
 <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script> 
</head>
<body>
  <div class="container">
    <h2 class="mt-3 mb-3">Transaction Detalis</h2>
    <div class="row">
          <span>Your payment was failed, please try again.</span><br/>
    </div>
  </div>
</body>
</html>