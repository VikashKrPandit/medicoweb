<!DOCTYPE html>
<html>
<head>
<meta charset=”utf-8″ />
<title>Codeigniter email template</title>
<meta name=”viewport” content=”width=device-width, initial-scale=1.0″ />
</head>
<body>
<div>

<style>*{margin:0px;padding:0px;}</style>
<table bgcolor=”#ececec” style=”border-bottom:1px solid #e0e0e0;width: 100%;margin:0px;”>
<tr>
<td style=”display:block!important;max-width:600px!important;margin:0 auto!important;clear:both!important;”>
<div style=”padding:15px;max-width:600px;margin:0 auto;display:block;”>
<table bgcolor=”#29BAB2″>
<tr>
<td><img src=”http://manojpatial.com/wp-content/uploads/2018/04/mp-logo-big.png” /></td>
</tr>
</table>
</div>
</td>
</tr>
</table>
<table style=”width: 100%;”>
<tr>
<td style=”display:block!important;max-width:600px!important;clear:both!important;margin:0 auto;” bgcolor=”#FFFFFF” align=”center”>
<div style=”padding:15px;max-width:600px;display:block;margin:0 auto;”>
<table>
<tr>
<td style=”font-family: Open Sans,arial,sans-serif; font-size:16px;”>
<h3 style=”font-family: Open Sans,arial,sans-serif; font-size:22px;margin-bottom:10px;”>Dear {name}</h3>
<p style=”font-family: Open Sans,arial,sans-serif; font-size: 16px;margin-bottom:20px;”>Thanks for signing up to http://manojpatial.com</p>
<p style=”font-family: Open Sans,arial,sans-serif; font-size: 16px;margin-bottom:20px;”>Please find your login details below</p>
<p style=”margin-bottom: 10px;line-height:1.6;font-family: Open Sans,arial,sans-serif; font-size: 16px;”>
Url: {URL}<br/>
Login Email: {user_name}<br/>
Password: {password}<br/>
</p><br/>
<p style=”margin-bottom: 10px;line-height:1.6;font-family: Open Sans,arial,sans-serif; font-size: 16px;”>
Thanks & Regards,<br/>Manoj Patial<br/></p>
</td>
</tr>
</table>
</div>
</td>
</tr>
</table>
</body>
</html>